@extends('layout')

@section('body')
    <main class="prose">
        <h1>Explorer demo app</h1>
        <ul>
            <li><a href="/search">Start searching</a></li>
            <li><a href="https://jeroen-g.github.io/Explorer/">Visit documentation</a></li>
        </ul>
    </main>
@endsection
