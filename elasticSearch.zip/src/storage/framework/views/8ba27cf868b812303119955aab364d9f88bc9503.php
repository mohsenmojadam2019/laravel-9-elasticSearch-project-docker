<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <title>Explorer demo app</title>
</head>
<body class="m-10">
    <?php echo $__env->yieldContent('body'); ?>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/layout.blade.php ENDPATH**/ ?>