<?php $__env->startSection('body'); ?>
    <main>
        <section class="prose">
            <h1>Paginated cartographers</h1>
            <ul>
                <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($person->name); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>

            <span>page <?php echo e($people->currentPage()); ?> of <?php echo e(round($people->total() / $people->perPage())); ?></span>
            <div>
                <?php if($people->currentPage() !== 1): ?><a href="<?php echo e($people->previousPageUrl()); ?>">Previous</a><?php endif; ?>
                <?php if($people->hasMorePages()): ?><a href="<?php echo e($people->nextPageUrl()); ?>">Next</a><?php endif; ?>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/list.blade.php ENDPATH**/ ?>