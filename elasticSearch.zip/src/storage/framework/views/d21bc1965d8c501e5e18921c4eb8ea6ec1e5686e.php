<?php $__env->startSection('body'); ?>
    <main class="prose">
        <h1>Explorer demo app</h1>
        <ul>
            <li><a href="/search">Start searching</a></li>
            <li><a href="https://jeroen-g.github.io/Explorer/">Visit documentation</a></li>
        </ul>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/welcome.blade.php ENDPATH**/ ?>