<?php $__env->startSection('body'); ?>
    <main>
        <section class="grid gap-10 grid-cols-2">
            <form action="/search" method="post" class="prose">
                <?php echo csrf_field(); ?>
                <h1>Search cartographers</h1>

                <fieldset class="my-5">
                    <label class="flex flex-col text-gray-500">
                        Keywords
                        <input type="text" name="keywords" autocomplete="off" />
                    </label>
                </fieldset>

                <fieldset class="my-5 flex flex-col">
                    <div class="flex flex-col text-gray-500">Places</div>
                    <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label>
                            <input type="checkbox" name="countries[]" value="<?php echo e($country); ?>" />
                            <?php echo e($country); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </fieldset>

                <fieldset class="my-5 flex flex-col">
                    <div class="flex flex-col text-gray-500">Periods</div>
                    <?php $__currentLoopData = $periods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $period): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label>
                            <input type="checkbox" name="periods[]" value="<?php echo e($period); ?>" />
                            <?php echo e($period); ?>

                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </fieldset>

                <fieldset class="my-5">
                    <button class="bg-blue-300 font-medium px-10 py-2 rounded mt-2" type="submit">Search</button>
                </fieldset>
            </form>

            <div class="prose">
                <h2>Results</h2>
                <ul>
                    <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($person->name); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </section>

        <section class="prose mt-10 max-w-5xl">
            <h2>Query</h2>
            <pre class=""><?php echo e($query ?? 'none'); ?></pre>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/search.blade.php ENDPATH**/ ?>